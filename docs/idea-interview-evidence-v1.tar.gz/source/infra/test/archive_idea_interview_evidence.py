"""Package fixed local development evidence; no network, model or DB writes."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parents[1]
FRONT = ROOT.parent / 'jumpserve-front-end'
VERSIONS = {'research-ideas-v'+str(n) for n in range(3, 9)}

def digest(raw): return hashlib.sha256(raw).hexdigest()

def main():
    files = {}
    def add_tree(directory, prefix):
        for path in sorted(directory.rglob('*')):
            if path.is_file(): files[prefix+'/'+str(path.relative_to(directory))] = path.read_bytes()
    reports = ROOT/'.test-artifacts/research-ideas/evaluations'
    for path in sorted(reports.glob('*/evaluation-report.json')):
        report = json.loads(path.read_text())
        if report.get('prompt_version') in VERSIONS:
            add_tree(path.parent, 'evaluations/'+path.parent.name)
    for root, pattern, prefix in (
        (FRONT, '.test-artifacts/idea-interview/browser/*/validation-report.json', 'interview-browser'),
        (FRONT, '.test-artifacts/idea-guide/browser/*/validation-report.json', 'guided-browser'),
        (ROOT, '.test-artifacts/research-ideas/database/*/validation-report.json', 'database'),
    ):
        for path in sorted(root.glob(pattern)):
            # Retain this feature's declared campaigns, including failed runs.
            data = json.loads(path.read_text())
            if prefix == 'database' and not any('interview publication' in c['name'] for c in data.get('checks', [])): continue
            if prefix == 'guided-browser' and path.parent.name < '2026-10-14T23-45': continue
            if prefix == 'database': files[prefix+'/'+path.parent.name+'/validation-report.json'] = path.read_bytes()
            else: add_tree(path.parent, prefix+'/'+path.parent.name)
    for pattern in ('docs/idea-interview*.md', 'database/*idea_interview*.sql', 'database/seed-research-ideas-prompt-v[3-8].json', 'test/idea-interview-evaluation-cases-v1*.json'):
        for path in sorted(ROOT.glob(pattern)): files['source/infra/'+str(path.relative_to(ROOT))] = path.read_bytes()
    for name in ('agent/idea_interview.py','agent/research_ideas.py','agent/handler.py','test/agent_ideas_test.py','test/agent_interview_test.py','test/archive_idea_interview_evidence.py','test/evaluate_research_ideas.py','test/serve_research_ideas_fixture.py','test/check_research_ideas_database.py'):
        files['source/infra/'+name] = (ROOT/name).read_bytes()
    for name in ('app/components/research-workflow/idea-guide.tsx','app/components/research-workflow/idea-conversation.tsx','lib/idea-interview.ts','lib/research-idea-api.ts','scripts/research-ideas-interview-cases.mjs','scripts/research-ideas-guided-cases.mjs','scripts/verify-research-ideas.mjs','tests/idea-interview.test.mjs','tests/research-idea-api.test.mjs'):
        files['source/frontend/'+name] = (FRONT/name).read_bytes()
    for root, names, prefix in ((ROOT, ['idea-interview-agent.log','idea-interview-database.log'], 'infra'), (FRONT, ['idea-interview-tests.log','idea-interview-lint.log'], 'frontend')):
        for name in names: files['logs/'+prefix+'/'+name] = (root/'.test-artifacts'/name).read_bytes()
    build = Path('/private/tmp/jumpserve-guided-release-20261014/jumpserve-front-end/.test-artifacts/idea-interview-build.log')
    files['logs/frontend/build.log'] = build.read_bytes()
    manifest = [dict(path=name, sha256=digest(raw), bytes=len(raw)) for name, raw in sorted(files.items())]
    files['manifest.json'] = (json.dumps(manifest, indent=2)+'\n').encode()
    destination = ROOT/'docs/idea-interview-evidence-v1.tar.gz'
    with destination.open('wb') as stream, gzip.GzipFile(filename='', mode='wb', fileobj=stream, mtime=0) as zipped, tarfile.open(fileobj=zipped, mode='w') as archive:
        for name, raw in sorted(files.items()):
            info = tarfile.TarInfo(name); info.size = len(raw); info.mode = 0o644
            archive.addfile(info, io.BytesIO(raw))
    with tarfile.open(destination, 'r:gz') as archive:
        restored = json.load(archive.extractfile('manifest.json'))
        for item in restored:
            raw = archive.extractfile(item['path']).read()
            assert len(raw) == item['bytes'] and digest(raw) == item['sha256'], item['path']
    print(json.dumps(dict(path=str(destination), sha256=digest(destination.read_bytes()), bytes=destination.stat().st_size,
        original_files=len(manifest), original_bytes=sum(item['bytes'] for item in manifest), retrieved_hashes_verified=True)))

if __name__ == '__main__': main()
